package org.poo.controlador;

import javafx.stage.Stage;
import org.poo.recurso.utilidad.Mensaje;

public class SalidaControlador {
    public static void verificar(Stage miEscenario){
        Mensaje.salir(miEscenario);
    }
}
