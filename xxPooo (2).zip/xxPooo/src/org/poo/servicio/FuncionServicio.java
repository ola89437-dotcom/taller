package org.poo.servicio;

import com.poo.persistence.NioFile;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.poo.api.ApiOperacionBD;
import org.poo.dto.FuncionDto;
import org.poo.modelo.Funcion;
import org.poo.recurso.constante.Persistencia;

public class FuncionServicio implements ApiOperacionBD<FuncionDto, Integer> {
    private NioFile miArchivo;
    private String nombrePersistencia;

    public FuncionServicio() {
        nombrePersistencia = Persistencia.RUTA_PROYECTO + Persistencia.SEPARADOR_CARPETAS + 
                            "miBaseDeDatos" + Persistencia.SEPARADOR_CARPETAS + "Funcion.txt";
        try {
            miArchivo = new NioFile(nombrePersistencia);
        } catch (IOException ex) {
            Logger.getLogger(FuncionServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getSerial() {
        try {
            return miArchivo.ultimoCodigo() + 1;
        } catch (IOException ex) {
            Logger.getLogger(FuncionServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public FuncionDto insertInto(FuncionDto dto, String ruta) {
        Funcion obj = new Funcion();
        obj.setIdFuncion(getSerial());
        obj.setFechaFuncion(dto.getFechaFuncion());
        obj.setHoraFuncion(dto.getHoraFuncion());
        obj.setPrecioFuncion(dto.getPrecioFuncion());
        obj.setCantidadBoletasFuncion((short) 0);

        String fila = obj.getIdFuncion() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getFechaFuncion() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getHoraFuncion() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getPrecioFuncion() + Persistencia.SEPARADOR_COLUMNAS
                + (dto.getPeliculaFuncion() != null ? dto.getPeliculaFuncion().getIdPelicula() : 0) + Persistencia.SEPARADOR_COLUMNAS
                + (dto.getSalaFuncion() != null ? dto.getSalaFuncion().getIdSala() : 0) + Persistencia.SEPARADOR_COLUMNAS
                + obj.getCantidadBoletasFuncion();

        if (miArchivo.agregarRegistro(fila)) {
            dto.setIdFuncion(obj.getIdFuncion());
            return dto;
        }
        return null;
    }

    @Override
    public List<FuncionDto> selectFrom() {
        List<FuncionDto> arreglo = new ArrayList<>();
        List<String> datos = miArchivo.obtenerDatos();

        for (String cadena : datos) {
            try {
                String[] cols = cadena.replace("@", "").split(Persistencia.SEPARADOR_COLUMNAS);
                if (cols.length >= 7) {
                    FuncionDto dto = new FuncionDto(
                        Integer.parseInt(cols[0].trim()),
                        cols[1].trim(), cols[2].trim(), Double.parseDouble(cols[3].trim()),
                        null, null, Short.parseShort(cols[6].trim())
                    );
                    arreglo.add(dto);
                }
            } catch (Exception ex) {
                Logger.getLogger(FuncionServicio.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return arreglo;
    }

    @Override
    public List<FuncionDto> selectFromWhereActivos() {
        return selectFrom();
    }

    @Override
    public int numRows() {
        try {
            return miArchivo.cantidadFilas();
        } catch (IOException ex) {
            Logger.getLogger(FuncionServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public Boolean deleteFrom(Integer codigo) {
        try {
            return !miArchivo.borrarFilaPosicion(codigo).isEmpty();
        } catch (IOException ex) {
            Logger.getLogger(FuncionServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public FuncionDto updateSet(Integer codigo, FuncionDto objeto, String ruta) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public FuncionDto getOne(Integer codigo) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
