package org.poo.servicio;

import com.poo.persistence.NioFile;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.poo.api.ApiOperacionBD;
import org.poo.dto.SalaDto;
import org.poo.modelo.Sala;
import org.poo.recurso.constante.Persistencia;

public class SalaServicio implements ApiOperacionBD<SalaDto, Integer> {
    private NioFile miArchivo;
    private String nombrePersistencia;

    public SalaServicio() {
        nombrePersistencia = Persistencia.RUTA_PROYECTO + Persistencia.SEPARADOR_CARPETAS + 
                            "miBaseDeDatos" + Persistencia.SEPARADOR_CARPETAS + "Sala.txt";
        try {
            miArchivo = new NioFile(nombrePersistencia);
        } catch (IOException ex) {
            Logger.getLogger(SalaServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getSerial() {
        try {
            return miArchivo.ultimoCodigo() + 1;
        } catch (IOException ex) {
            Logger.getLogger(SalaServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public SalaDto insertInto(SalaDto dto, String ruta) {
        Sala obj = new Sala();
        obj.setIdSala(getSerial());
        obj.setNombreSala(dto.getNombreSala());
        obj.setCapacidadSala(dto.getCapacidadSala());
        obj.setCantidadFuncionesSala((short) 0);

        String fila = obj.getIdSala() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNombreSala() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getCapacidadSala() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getCantidadFuncionesSala();

        if (miArchivo.agregarRegistro(fila)) {
            dto.setIdSala(obj.getIdSala());
            return dto;
        }
        return null;
    }

    @Override
    public List<SalaDto> selectFrom() {
        List<SalaDto> arreglo = new ArrayList<>();
        List<String> datos = miArchivo.obtenerDatos();

        for (String cadena : datos) {
            try {
                String[] cols = cadena.replace("@", "").split(Persistencia.SEPARADOR_COLUMNAS);
                if (cols.length >= 4) {
                    SalaDto dto = new SalaDto(
                        Integer.parseInt(cols[0].trim()),
                        cols[1].trim(), Short.parseShort(cols[2].trim()),
                        Short.parseShort(cols[3].trim())
                    );
                    arreglo.add(dto);
                }
            } catch (Exception ex) {
                Logger.getLogger(SalaServicio.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return arreglo;
    }

    @Override
    public List<SalaDto> selectFromWhereActivos() {
        return selectFrom();
    }

    @Override
    public int numRows() {
        try {
            return miArchivo.cantidadFilas();
        } catch (IOException ex) {
            Logger.getLogger(SalaServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public Boolean deleteFrom(Integer codigo) {
        try {
            return !miArchivo.borrarFilaPosicion(codigo).isEmpty();
        } catch (IOException ex) {
            Logger.getLogger(SalaServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public SalaDto updateSet(Integer codigo, SalaDto objeto, String ruta) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public SalaDto getOne(Integer codigo) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
