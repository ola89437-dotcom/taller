package org.poo.servicio;

import com.poo.persistence.NioFile;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.poo.api.ApiOperacionBD;
import org.poo.dto.ProductoraDto;
import org.poo.modelo.Productora;
import org.poo.recurso.constante.Persistencia;
import org.poo.recurso.utilidad.GestorImagen;

public class ProductoraServicio implements ApiOperacionBD<ProductoraDto, Integer> {
    private NioFile miArchivo;
    private String nombrePersistencia;

    public ProductoraServicio() {
        nombrePersistencia = Persistencia.RUTA_PROYECTO + Persistencia.SEPARADOR_CARPETAS + 
                            "miBaseDeDatos" + Persistencia.SEPARADOR_CARPETAS + "Productora.txt";
        try {
            miArchivo = new NioFile(nombrePersistencia);
        } catch (IOException ex) {
            Logger.getLogger(ProductoraServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getSerial() {
        try {
            return miArchivo.ultimoCodigo() + 1;
        } catch (IOException ex) {
            Logger.getLogger(ProductoraServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public ProductoraDto insertInto(ProductoraDto dto, String ruta) {
        Productora obj = new Productora();
        obj.setIdProductora(getSerial());
        obj.setNombreProductora(dto.getNombreProductora());
        obj.setFundadorProductora(dto.getFundadorProductora());
        obj.setPaisProductora(dto.getPaisProductora());
        obj.setCantidadPeliculasProductora((short) 0);
        obj.setNombreImagenPublicoProductora(dto.getNombreImagenPublicoProductora());
        obj.setNombreImagenPrivadoProductora(GestorImagen.grabarLaImagen(ruta));

        String fila = obj.getIdProductora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNombreProductora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getFundadorProductora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getPaisProductora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getCantidadPeliculasProductora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNombreImagenPublicoProductora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNombreImagenPrivadoProductora();

        if (miArchivo.agregarRegistro(fila)) {
            dto.setIdProductora(obj.getIdProductora());
            return dto;
        }
        return null;
    }

    @Override
    public List<ProductoraDto> selectFrom() {
        List<ProductoraDto> arreglo = new ArrayList<>();
        List<String> datos = miArchivo.obtenerDatos();

        for (String cadena : datos) {
            try {
                String[] cols = cadena.replace("@", "").split(Persistencia.SEPARADOR_COLUMNAS);
                if (cols.length >= 7) {
                    ProductoraDto dto = new ProductoraDto(
                        Integer.parseInt(cols[0].trim()),
                        cols[1].trim(), cols[2].trim(), cols[3].trim(),
                        Short.parseShort(cols[4].trim()), cols[5].trim(), cols[6].trim()
                    );
                    arreglo.add(dto);
                }
            } catch (Exception ex) {
                Logger.getLogger(ProductoraServicio.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return arreglo;
    }

    @Override
    public List<ProductoraDto> selectFromWhereActivos() {
        return selectFrom();
    }

    @Override
    public int numRows() {
        try {
            return miArchivo.cantidadFilas();
        } catch (IOException ex) {
            Logger.getLogger(ProductoraServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public Boolean deleteFrom(Integer codigo) {
        try {
            return !miArchivo.borrarFilaPosicion(codigo).isEmpty();
        } catch (IOException ex) {
            Logger.getLogger(ProductoraServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public ProductoraDto updateSet(Integer codigo, ProductoraDto objeto, String ruta) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ProductoraDto getOne(Integer codigo) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}