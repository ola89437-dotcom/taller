package org.poo.servicio;

import com.poo.persistence.NioFile;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.poo.api.ApiOperacionBD;
import org.poo.dto.BoletaDto;
import org.poo.modelo.Boleta;
import org.poo.recurso.constante.Persistencia;

public class BoletaServicio implements ApiOperacionBD<BoletaDto, Integer> {
    private NioFile miArchivo;
    private String nombrePersistencia;

    public BoletaServicio() {
        nombrePersistencia = Persistencia.RUTA_PROYECTO + Persistencia.SEPARADOR_CARPETAS + 
                            "miBaseDeDatos" + Persistencia.SEPARADOR_CARPETAS + "Boleta.txt";
        try {
            miArchivo = new NioFile(nombrePersistencia);
        } catch (IOException ex) {
            Logger.getLogger(BoletaServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getSerial() {
        int id = 0;
        try {
            id = miArchivo.ultimoCodigo() + 1;
        } catch (IOException ex) {
            Logger.getLogger(BoletaServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }

    @Override
    public BoletaDto insertInto(BoletaDto dto, String ruta) {
        Boleta objBoleta = new Boleta();
        objBoleta.setIdBoleta(getSerial());
        objBoleta.setNumeroAsientoBoleta(dto.getNumeroAsientoBoleta());
        objBoleta.setFechaCompraBoleta(dto.getFechaCompraBoleta());
        objBoleta.setEstadoBoleta(dto.getEstadoBoleta());

        String filaGrabar = objBoleta.getIdBoleta() + Persistencia.SEPARADOR_COLUMNAS
                + objBoleta.getNumeroAsientoBoleta() + Persistencia.SEPARADOR_COLUMNAS
                + objBoleta.getFechaCompraBoleta() + Persistencia.SEPARADOR_COLUMNAS
                + objBoleta.getEstadoBoleta();

        if (miArchivo.agregarRegistro(filaGrabar)) {
            dto.setIdBoleta(objBoleta.getIdBoleta());
            return dto;
        }
        return null;
    }

    @Override
    public List<BoletaDto> selectFrom() {
        List<BoletaDto> arreglo = new ArrayList<>();
        List<String> arregloDatos = miArchivo.obtenerDatos();

        for (String cadena : arregloDatos) {
            try {
                cadena = cadena.replace("@", "");
                String[] columnas = cadena.split(Persistencia.SEPARADOR_COLUMNAS);

                int id = Integer.parseInt(columnas[0].trim());
                String asiento = columnas[1].trim();
                String fecha = columnas[2].trim();
                Boolean estado = Boolean.valueOf(columnas[3].trim());

                BoletaDto dto = new BoletaDto(id, asiento, fecha, null, null, estado);
                arreglo.add(dto);
            } catch (NumberFormatException error) {
                Logger.getLogger(BoletaServicio.class.getName()).log(Level.SEVERE, null, error);
            }
        }
        return arreglo;
    }

    @Override
    public List<BoletaDto> selectFromWhereActivos() {
        List<BoletaDto> arreglo = new ArrayList<>();
        List<String> arregloDatos = miArchivo.obtenerDatos();

        for (String cadena : arregloDatos) {
            try {
                cadena = cadena.replace("@", "");
                String[] columnas = cadena.split(Persistencia.SEPARADOR_COLUMNAS);

                int id = Integer.parseInt(columnas[0].trim());
                String asiento = columnas[1].trim();
                String fecha = columnas[2].trim();
                Boolean estado = Boolean.valueOf(columnas[3].trim());

                if (estado) {
                    BoletaDto dto = new BoletaDto(id, asiento, fecha, null, null, estado);
                    arreglo.add(dto);
                }
            } catch (NumberFormatException error) {
                Logger.getLogger(BoletaServicio.class.getName()).log(Level.SEVERE, null, error);
            }
        }
        return arreglo;
    }

    @Override
    public int numRows() {
        int cantidad = 0;
        try {
            cantidad = miArchivo.cantidadFilas();
        } catch (IOException ex) {
            Logger.getLogger(BoletaServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cantidad;
    }

    @Override
    public Boolean deleteFrom(Integer codigo) {
        Boolean correcto = false;
        try {
            List<String> arreglo = miArchivo.borrarFilaPosicion(codigo);
            if (!arreglo.isEmpty()) {
                correcto = true;
            }
        } catch (IOException ex) {
            Logger.getLogger(BoletaServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return correcto;
    }

    @Override
    public BoletaDto updateSet(Integer codigo, BoletaDto objeto, String ruta) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public BoletaDto getOne(Integer codigo) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}