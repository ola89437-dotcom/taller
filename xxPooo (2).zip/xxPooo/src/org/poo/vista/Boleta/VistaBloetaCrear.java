package org.poo.vista.boleta;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.poo.controlador.boleta.BoletaControladorGrabar;
import org.poo.dto.BoletaDto;
import org.poo.recurso.constante.Configuracion;
import org.poo.recurso.utilidad.Formulario;
import org.poo.recurso.utilidad.Marco;
import org.poo.recurso.utilidad.Mensaje;

public class VistaBloetaCrear extends StackPane {
    private static final int H_GAP = 10;
    private static final int V_GAP = 20;
    private static final int ALTO_FILA = 40;
    private static final int ALTO_CAJA = 35;
    private static final int TAMANIO_FUENTE = 20;
    private static final double AJUSTE_TITULO = 0.1;

    private final GridPane miGrilla;
    private final Rectangle miMarco;

    private TextField txtNumeroAsiento;
    private TextField txtFechaCompra;

    public VistaBloetaCrear(Stage esce, double ancho, double alto) {
        setAlignment(Pos.CENTER);
        miGrilla = new GridPane();
        miMarco = Marco.crear(esce,
                Configuracion.MARCO_ALTO_PORCENTAJE,
                Configuracion.MARCO_ANCHO_PORCENTAJE,
                Configuracion.DEGRADE_ARREGLO_GENERO,
                Configuracion.DEGRADE_BORDE);

        getChildren().add(miMarco);
        configurarMiGrilla(ancho, alto);
        crearTitulo();
        crearFormulario();
        colocarFrmElegante();
        getChildren().add(miGrilla);
    }

    private void configurarMiGrilla(double ancho, double alto) {
        double miAnchoGrilla = ancho * Configuracion.GRILLA_ANCHO_PORCENTAJE;
        miGrilla.setHgap(H_GAP);
        miGrilla.setVgap(V_GAP);
        miGrilla.setPrefSize(miAnchoGrilla, alto);
        miGrilla.setMinSize(miAnchoGrilla, alto);
        miGrilla.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);

        ColumnConstraints col0 = new ColumnConstraints();
        ColumnConstraints col1 = new ColumnConstraints();

        col0.setPrefWidth(250);
        col1.setPrefWidth(250);
        col1.setHgrow(Priority.ALWAYS);

        miGrilla.getColumnConstraints().addAll(col0, col1);

        for (int i = 0; i < 6; i++) {
            javafx.scene.layout.RowConstraints fila = new javafx.scene.layout.RowConstraints();
            fila.setMinHeight(ALTO_FILA);
            fila.setMaxHeight(ALTO_FILA);
            miGrilla.getRowConstraints().add(fila);
        }
    }

    private void crearTitulo() {
        Text miTitulo = new Text("CREAR BOLETA");
        miTitulo.setFill(Color.web(Configuracion.MORADO_OSCURO));
        miTitulo.setFont(Font.font("Rockwell", FontWeight.BOLD, 28));
        GridPane.setHalignment(miTitulo, HPos.CENTER);
        GridPane.setMargin(miTitulo, new Insets(30, 0, 0, 0));
        miGrilla.add(miTitulo, 0, 0, 2, 1);
    }

    private void crearFormulario() {
        Label lblNumeroAsiento = new Label("Número de Asiento:");
        lblNumeroAsiento.setFont(Font.font("Times New Roman", FontPosture.ITALIC, TAMANIO_FUENTE));
        miGrilla.add(lblNumeroAsiento, 0, 2);

        txtNumeroAsiento = new TextField();
        txtNumeroAsiento.setPromptText("Ej: A1, B5");
        GridPane.setHgrow(txtNumeroAsiento, Priority.ALWAYS);
        txtNumeroAsiento.setPrefHeight(ALTO_CAJA);
        Formulario.cantidadCaracteres(txtNumeroAsiento, 10);
        miGrilla.add(txtNumeroAsiento, 1, 2);

        Label lblFechaCompra = new Label("Fecha de Compra:");
        lblFechaCompra.setFont(Font.font("Times New Roman", FontPosture.ITALIC, TAMANIO_FUENTE));
        miGrilla.add(lblFechaCompra, 0, 3);

        txtFechaCompra = new TextField();
        txtFechaCompra.setPromptText("YYYY-MM-DD");
        GridPane.setHgrow(txtFechaCompra, Priority.ALWAYS);
        txtFechaCompra.setPrefHeight(ALTO_CAJA);
        Formulario.cantidadCaracteres(txtFechaCompra, 10);
        miGrilla.add(txtFechaCompra, 1, 3);

        Button btnGrabar = new Button("Grabar Boleta");
        btnGrabar.setTextFill(Color.web(Configuracion.MORADO_OSCURO));
        btnGrabar.setMaxWidth(Double.MAX_VALUE);
        btnGrabar.setFont(Font.font("Times New Roman", TAMANIO_FUENTE));
        btnGrabar.setOnAction((e) -> guardarBoleta());
        miGrilla.add(btnGrabar, 1, 4);
    }

    private Boolean formularioCompleto() {
        if (txtNumeroAsiento.getText().isBlank()) {
            Mensaje.mostrar(Alert.AlertType.WARNING, this.getScene().getWindow(),
                    "Atención", "Por favor ingresa el número de asiento");
            txtNumeroAsiento.requestFocus();
            return false;
        }
        if (txtFechaCompra.getText().isBlank()) {
            Mensaje.mostrar(Alert.AlertType.WARNING, this.getScene().getWindow(),
                    "Atención", "Por favor ingresa la fecha de compra");
            txtFechaCompra.requestFocus();
            return false;
        }
        return true;
    }

    private void guardarBoleta() {
        if (formularioCompleto()) {
            BoletaDto dto = new BoletaDto();
            dto.setNumeroAsientoBoleta(txtNumeroAsiento.getText());
            dto.setFechaCompraBoleta(txtFechaCompra.getText());
            dto.setEstadoBoleta(true);

            if (BoletaControladorGrabar.crearBoleta(dto)) {
                Mensaje.mostrar(Alert.AlertType.INFORMATION, null,
                        "Éxito", "Boleta guardada correctamente");
                limpiarFormulario();
            } else {
                Mensaje.mostrar(Alert.AlertType.ERROR, null,
                        "Error", "No se pudo guardar la boleta");
            }
        }
    }

    private void limpiarFormulario() {
        txtNumeroAsiento.setText("");
        txtFechaCompra.setText("");
        txtNumeroAsiento.requestFocus();
    }

    private void colocarFrmElegante() {
        Runnable calcular = () -> {
            double alturaMarco = miMarco.getHeight();
            if (alturaMarco > 0) {
                double desplazamiento = alturaMarco * AJUSTE_TITULO;
                miGrilla.setTranslateY(alturaMarco / 8 + desplazamiento);
            }
        };

        calcular.run();
        miMarco.heightProperty().addListener((obs, antes, despues) -> {
            calcular.run();
        });
    }
}