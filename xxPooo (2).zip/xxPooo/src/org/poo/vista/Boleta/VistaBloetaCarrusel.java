package org.poo.vista.boleta;

import javafx.animation.FadeTransition;
import javafx.beans.binding.Bindings;
import javafx.beans.property.*;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.SubScene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.poo.controlador.boleta.BoletaControladorListar;
import org.poo.dto.BoletaDto;
import org.poo.recurso.constante.Configuracion;
import org.poo.recurso.dominio.Ruta;
import org.poo.recurso.utilidad.Fondo;
import org.poo.recurso.utilidad.Icono;
import org.poo.recurso.utilidad.Marco;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VistaBoletaCarrusel extends SubScene {

    private final Stage miEscenario;
    private final BorderPane miBorderPane;
    private final VBox organizadorVertical;

    private List<BoletaDto> boletas;
    private int indiceActual;

    // PROPIEDADES
    private StringProperty tituloBoleta;
    private StringProperty asiento;
    private StringProperty fecha;
    private BooleanProperty estado;
    private ObjectProperty<Image> imagenBoleta;

    public VistaBoletaCarrusel(Stage escenarioPadre, double ancho, double alto) {
        super(new BorderPane(), ancho, alto);

        miEscenario = escenarioPadre;
        miBorderPane = (BorderPane) this.getRoot();
        organizadorVertical = new VBox(12);

        boletas = BoletaControladorListar.obtenerBoletas();
        indiceActual = 0;

        configurarOrganizador();
        crearTitulo();
        construirPanelIzquierdo();
        construirPanelDerecho();
        construirPanelCentro();
    }

    private void configurarOrganizador() {
        organizadorVertical.setAlignment(Pos.TOP_CENTER);
        organizadorVertical.prefWidthProperty().bind(miEscenario.widthProperty());
        organizadorVertical.prefHeightProperty().bind(miEscenario.heightProperty());
    }

    private void crearTitulo() {
        Region espacio = new Region();
        espacio.prefHeightProperty().bind(miEscenario.heightProperty().multiply(0.08));
        organizadorVertical.getChildren().add(espacio);

        tituloBoleta = new SimpleStringProperty();
        actualizarTitulo();

        Label lblTitulo = new Label();
        lblTitulo.textProperty().bind(tituloBoleta);
        lblTitulo.setFont(Font.font("Rockwell", FontWeight.BOLD, 26));
        lblTitulo.setTextFill(Color.web(Configuracion.MORADO_OSCURO));

        organizadorVertical.getChildren().add(lblTitulo);
    }

    private void construirPanelIzquierdo() {
        Button btnAnterior = new Button();
        btnAnterior.setGraphic(Icono.obtenerIcono("btnAtras.png", 80));
        btnAnterior.setCursor(Cursor.HAND);
        btnAnterior.setStyle("-fx-background-color: transparent;");

        btnAnterior.setOnAction(e -> navegar("anterior"));

        StackPane izq = new StackPane(btnAnterior);
        izq.prefWidthProperty().bind(miEscenario.widthProperty().multiply(0.14));

        miBorderPane.setLeft(izq);
    }

    private void construirPanelDerecho() {
        Button btnSig = new Button();
        btnSig.setGraphic(Icono.obtenerIcono("btnSiguiente.png", 80));
        btnSig.setCursor(Cursor.HAND);
        btnSig.setStyle("-fx-background-color: transparent;");

        btnSig.setOnAction(e -> navegar("siguiente"));

        StackPane der = new StackPane(btnSig);
        der.prefWidthProperty().bind(miEscenario.widthProperty().multiply(0.14));

        miBorderPane.setRight(der);
    }

    private void construirPanelCentro() {
        StackPane centro = new StackPane();
        centro.setBackground(Fondo.asignarAleatorio(Configuracion.FONDOS));

        Rectangle marco = Marco.crear(miEscenario, 0.60, 0.75,
                Configuracion.DEGRADE_ARREGLO_PELICULA,
                Configuracion.DEGRADE_BORDE);

        centro.getChildren().addAll(marco, organizadorVertical);
        miBorderPane.setCenter(centro);

        cargarPropiedadesYComponentes();
    }

    private void cargarPropiedadesYComponentes() {
        if (boletas.isEmpty()) return;

        BoletaDto obj = boletas.get(indiceActual);

        asiento = new SimpleStringProperty("Asiento: " + obj.getNumeroAsientoBoleta());
        fecha = new SimpleStringProperty("Fecha: " + obj.getFechaCompraBoleta());
        estado = new SimpleBooleanProperty(obj.getEstadoBoleta());
        imagenBoleta = new SimpleObjectProperty<>();

        // IMAGEN
        try {
            FileInputStream file = new FileInputStream(
                    Ruta.RUTA_FOTOS + Configuracion.SEPARADOR_CARPETA + obj.getNombreImagenPrivadoBoleta()
            );
            imagenBoleta.set(new Image(file));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(VistaBoletaCarrusel.class.getName()).log(Level.SEVERE, null, ex);
        }

        actualizarPanelInformacion();
    }

    private void actualizarPanelInformacion() {
        organizadorVertical.getChildren().removeIf(node -> !(node instanceof Label) ||
                ((Label) node).textProperty() == tituloBoleta);

        // IMAGEN
        ImageView img = new ImageView();
        img.imageProperty().bind(imagenBoleta);
        img.setFitHeight(240);
        img.setPreserveRatio(true);
        organizadorVertical.getChildren().add(img);

        // ASIENTO
        Label lblAsiento = new Label();
        lblAsiento.textProperty().bind(asiento);
        lblAsiento.setFont(Font.font("Verdana", 20));
        lblAsiento.setTextFill(Color.web(Configuracion.MORADO_OSCURO));
        organizadorVertical.getChildren().add(lblAsiento);

        // FECHA
        Label lblFecha = new Label();
        lblFecha.textProperty().bind(fecha);
        lblFecha.setFont(Font.font("Verdana", 20));
        lblFecha.setTextFill(Color.web(Configuracion.MORADO_OSCURO));
        organizadorVertical.getChildren().add(lblFecha);

        // ESTADO
        Label lblEstado = new Label();
        lblEstado.textProperty().bind(
                Bindings.when(estado).then("Estado: Activa").otherwise("Estado: Inactiva")
        );
        lblEstado.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
        lblEstado.styleProperty().bind(
                estado.map(v -> v ? "-fx-text-fill: #38B000;" : "-fx-text-fill: red;")
        );
        organizadorVertical.getChildren().add(lblEstado);

        agregarBotonesOpciones();
    }

    private void agregarBotonesOpciones() {
        Button btnEliminar = new Button();
        btnEliminar.setGraphic(Icono.obtenerIcono("iconoBorrar.png", 20));
        btnEliminar.setPrefWidth(45);
        btnEliminar.setCursor(Cursor.HAND);
        btnEliminar.setStyle("-fx-background-color: transparent;");

        Button btnEditar = new Button();
        btnEditar.setGraphic(Icono.obtenerIcono("iconoEditar.png", 20));
        btnEditar.setPrefWidth(45);
        btnEditar.setCursor(Cursor.HAND);
        btnEditar.setStyle("-fx-background-color: transparent;");

        HBox opciones = new HBox(10, btnEliminar, btnEditar);
        opciones.setAlignment(Pos.CENTER);

        organizadorVertical.getChildren().add(opciones);
    }

    private void navegar(String tipo) {
        if (boletas.isEmpty()) return;

        FadeTransition fade = new FadeTransition(Duration.millis(250), organizadorVertical);
        fade.setFromValue(1);
        fade.setToValue(0.2);

        fade.setOnFinished(e -> {
            if (tipo.equals("anterior"))
                indiceActual = (indiceActual == 0) ? boletas.size() - 1 : indiceActual - 1;
            else
                indiceActual = (indiceActual == boletas.size() - 1) ? 0 : indiceActual + 1;

            actualizarTitulo();
            cargarPropiedadesYComponentes();

            FadeTransition fadeIn = new FadeTransition(Duration.millis(250), organizadorVertical);
            fadeIn.setFromValue(0.2);
            fadeIn.setToValue(1);
            fadeIn.play();
        });

        fade.play();
    }

    private void actualizarTitulo() {
        tituloBoleta.set(
                "Detalle de la Boleta (" + (indiceActual + 1) + " / " + boletas.size() + ")"
        );
    }
}
