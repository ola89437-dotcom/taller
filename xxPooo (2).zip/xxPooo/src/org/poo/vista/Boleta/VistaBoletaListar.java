package org.poo.vista.boleta;

import java.util.List;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.poo.controlador.boleta.BoletaControladorListar;
import org.poo.dto.BoletaDto;
import org.poo.recurso.constante.Configuracion;
import org.poo.recurso.utilidad.Marco;

public class VistaBloetaListar extends StackPane {
    private final Rectangle marco;
    private final Stage miEscenario;
    private final VBox cajaVertical;
    private final TableView<BoletaDto> miTabla;

    private static final String ESTILO_CENTRAR = "-fx-alignment: CENTER;";
    private static final String ESTILO_IZQUIERDA = "-fx-alignment: CENTER-LEFT;";
    private static final String ESTILO_ROJO = "-fx-text-fill: red;" + ESTILO_CENTRAR;
    private static final String ESTILO_VERDE = "-fx-text-fill: green;" + ESTILO_CENTRAR;

    public VistaBloetaListar(Stage ventanaPadre, double ancho, double alto) {
        setAlignment(Pos.CENTER);
        miEscenario = ventanaPadre;
        marco = Marco.crear(miEscenario,
                Configuracion.MARCO_ALTO_PORCENTAJE,
                Configuracion.MARCO_ANCHO_PORCENTAJE,
                Configuracion.DEGRADE_ARREGLO_PELICULA,
                Configuracion.DEGRADE_BORDE
        );

        miTabla = new TableView<>();
        cajaVertical = new VBox(20);
        getChildren().add(marco);

        configurarCajaVertical();
        crearTitulo();
        crearTabla();
    }

    private void configurarCajaVertical() {
        cajaVertical.setAlignment(Pos.TOP_CENTER);
        cajaVertical.prefWidthProperty().bind(miEscenario.widthProperty());
        cajaVertical.prefHeightProperty().bind(miEscenario.heightProperty());
    }

    private void crearTitulo() {
        Region bloqueSeparador = new Region();
        bloqueSeparador.prefHeightProperty().bind(
                miEscenario.heightProperty().multiply(0.05));

        int cant = BoletaControladorListar.obtenerCantidadBoletas();
        Text titulo = new Text("LISTA DE BOLETAS (" + cant + ")");
        titulo.setFill(Color.web(Configuracion.MORADO_OSCURO));
        titulo.setFont(Font.font("Rockwell", FontWeight.BOLD, 28));

        cajaVertical.getChildren().addAll(bloqueSeparador, titulo);
    }

    private void crearTabla() {
        TableColumn<BoletaDto, Integer> colCodigo = new TableColumn<>("Código");
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("idBoleta"));
        colCodigo.prefWidthProperty().bind(miTabla.widthProperty().multiply(0.15));
        colCodigo.setStyle(ESTILO_CENTRAR);

        TableColumn<BoletaDto, String> colAsiento = new TableColumn<>("Asiento");
        colAsiento.setCellValueFactory(new PropertyValueFactory<>("numeroAsientoBoleta"));
        colAsiento.prefWidthProperty().bind(miTabla.widthProperty().multiply(0.25));
        colAsiento.setStyle(ESTILO_IZQUIERDA);

        TableColumn<BoletaDto, String> colFecha = new TableColumn<>("Fecha Compra");
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fechaCompraBoleta"));
        colFecha.prefWidthProperty().bind(miTabla.widthProperty().multiply(0.30));
        colFecha.setStyle(ESTILO_CENTRAR);

        TableColumn<BoletaDto, String> colEstado = new TableColumn<>("Estado");
        colEstado.setCellValueFactory(obj -> {
            String estado = obj.getValue().getEstadoBoleta() ? "Activa" : "Inactiva";
            return new SimpleStringProperty(estado);
        });
        colEstado.setCellFactory(col -> new TableCell<BoletaDto, String>() {
            @Override
            protected void updateItem(String text, boolean empty) {
                super.updateItem(text, empty);
                if (empty || text == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(text);
                    setStyle("Activa".equals(text) ? ESTILO_VERDE : ESTILO_ROJO);
                }
            }
        });
        colEstado.prefWidthProperty().bind(miTabla.widthProperty().multiply(0.30));

        miTabla.getColumns().addAll(colCodigo, colAsiento, colFecha, colEstado);

        List<BoletaDto> datos = BoletaControladorListar.obtenerBoletas();
        ObservableList<BoletaDto> datosTabla = FXCollections.observableArrayList(datos);
        miTabla.setItems(datosTabla);
        miTabla.setPlaceholder(new Text("No hay Boletas Registradas."));
        miTabla.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);

        miTabla.maxWidthProperty().bind(miEscenario.widthProperty().multiply(0.70));
        miTabla.maxHeightProperty().bind(miEscenario.heightProperty().multiply(0.50));

        miEscenario.heightProperty().addListener((o, oldVal, newVal) -> miTabla.setPrefHeight(newVal.doubleValue()));
        VBox.setVgrow(miTabla, Priority.ALWAYS);

        cajaVertical.getChildren().add(miTabla);
        getChildren().add(cajaVertical);
    }
}