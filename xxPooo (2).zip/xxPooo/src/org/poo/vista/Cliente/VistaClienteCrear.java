package org.poo.vista.cliente;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.poo.controlador.cliente.ClienteControladorGrabar;
import org.poo.dto.ClienteDto;
import org.poo.recurso.constante.Configuracion;
import org.poo.recurso.utilidad.Formulario;
import org.poo.recurso.utilidad.Marco;
import org.poo.recurso.utilidad.Mensaje;

public class VistaClienteCrear extends StackPane {
    private static final int H_GAP = 10;
    private static final int V_GAP = 20;
    private static final int ALTO_FILA = 40;
    private static final int ALTO_CAJA = 35;
    private static final int TAMANIO_FUENTE = 20;
    private static final double AJUSTE_TITULO = 0.1;

    private final GridPane miGrilla;
    private final Rectangle miMarco;

    private TextField txtNombre;
    private TextField txtApellido;
    private TextField txtDocumento;
    private TextField txtTelefono;
    private TextField txtEmail;

    public VistaClienteCrear(Stage esce, double ancho, double alto) {
        setAlignment(Pos.CENTER);
        miGrilla = new GridPane();
        miMarco = Marco.crear(esce,
                Configuracion.MARCO_ALTO_PORCENTAJE,
                Configuracion.MARCO_ANCHO_PORCENTAJE,
                Configuracion.DEGRADE_ARREGLO_GENERO,
                Configuracion.DEGRADE_BORDE);

        getChildren().add(miMarco);
        configurarMiGrilla(ancho, alto);
        crearTitulo();
        crearFormulario();
        colocarFrmElegante();
        getChildren().add(miGrilla);
    }

    private void configurarMiGrilla(double ancho, double alto) {
        double miAnchoGrilla = ancho * Configuracion.GRILLA_ANCHO_PORCENTAJE;
        miGrilla.setHgap(H_GAP);
        miGrilla.setVgap(V_GAP);
        miGrilla.setPrefSize(miAnchoGrilla, alto);
        miGrilla.setMinSize(miAnchoGrilla, alto);
        miGrilla.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);

        ColumnConstraints col0 = new ColumnConstraints();
        ColumnConstraints col1 = new ColumnConstraints();

        col0.setPrefWidth(200);
        col1.setPrefWidth(250);
        col1.setHgrow(Priority.ALWAYS);

        miGrilla.getColumnConstraints().addAll(col0, col1);

        for (int i = 0; i < 10; i++) {
            javafx.scene.layout.RowConstraints fila = new javafx.scene.layout.RowConstraints();
            fila.setMinHeight(ALTO_FILA);
            fila.setMaxHeight(ALTO_FILA);
            miGrilla.getRowConstraints().add(fila);
        }
    }

    private void crearTitulo() {
        Text miTitulo = new Text("CREAR CLIENTE");
        miTitulo.setFill(Color.web(Configuracion.MORADO_OSCURO));
        miTitulo.setFont(Font.font("Rockwell", FontWeight.BOLD, 28));
        GridPane.setHalignment(miTitulo, HPos.CENTER);
        GridPane.setMargin(miTitulo, new Insets(30, 0, 0, 0));
        miGrilla.add(miTitulo, 0, 0, 2, 1);
    }

    private void crearFormulario() {
        // Nombre
        Label lblNombre = new Label("Nombre:");
        lblNombre.setFont(Font.font("Times New Roman", FontPosture.ITALIC, TAMANIO_FUENTE));
        miGrilla.add(lblNombre, 0, 2);

        txtNombre = new TextField();
        txtNombre.setPromptText("Ingresa nombre");
        GridPane.setHgrow(txtNombre, Priority.ALWAYS);
        txtNombre.setPrefHeight(ALTO_CAJA);
        Formulario.cantidadCaracteres(txtNombre, 50);
        miGrilla.add(txtNombre, 1, 2);

        // Apellido
        Label lblApellido = new Label("Apellido:");
        lblApellido.setFont(Font.font("Times New Roman", FontPosture.ITALIC, TAMANIO_FUENTE));
        miGrilla.add(lblApellido, 0, 3);

        txtApellido = new TextField();
        txtApellido.setPromptText("Ingresa apellido");
        GridPane.setHgrow(txtApellido, Priority.ALWAYS);
        txtApellido.setPrefHeight(ALTO_CAJA);
        Formulario.cantidadCaracteres(txtApellido, 50);
        miGrilla.add(txtApellido, 1, 3);

        // Documento
        Label lblDocumento = new Label("Documento:");
        lblDocumento.setFont(Font.font("Times New Roman", FontPosture.ITALIC, TAMANIO_FUENTE));
        miGrilla.add(lblDocumento, 0, 4);

        txtDocumento = new TextField();
        txtDocumento.setPromptText("Ej: 12345678");
        GridPane.setHgrow(txtDocumento, Priority.ALWAYS);
        txtDocumento.setPrefHeight(ALTO_CAJA);
        Formulario.soloNumeros(txtDocumento);
        Formulario.cantidadCaracteres(txtDocumento, 20);
        miGrilla.add(txtDocumento, 1, 4);

        // Teléfono
        Label lblTelefono = new Label("Teléfono:");
        lblTelefono.setFont(Font.font("Times New Roman", FontPosture.ITALIC, TAMANIO_FUENTE));
        miGrilla.add(lblTelefono, 0, 5);

        txtTelefono = new TextField();
        txtTelefono.setPromptText("Ej: 3101234567");
        GridPane.setHgrow(txtTelefono, Priority.ALWAYS);
        txtTelefono.setPrefHeight(ALTO_CAJA);
        Formulario.soloNumeros(txtTelefono);
        Formulario.cantidadCaracteres(txtTelefono, 20);
        miGrilla.add(txtTelefono, 1, 5);

        // Email
        Label lblEmail = new Label("Email:");
        lblEmail.setFont(Font.font("Times New Roman", FontPosture.ITALIC, TAMANIO_FUENTE));
        miGrilla.add(lblEmail, 0, 6);

        txtEmail = new TextField();
        txtEmail.setPromptText("correo@ejemplo.com");
        GridPane.setHgrow(txtEmail, Priority.ALWAYS);
        txtEmail.setPrefHeight(ALTO_CAJA);
        Formulario.cantidadCaracteres(txtEmail, 100);
        miGrilla.add(txtEmail, 1, 6);

        // Botón Grabar
        Button btnGrabar = new Button("Grabar Cliente");
        btnGrabar.setTextFill(Color.web(Configuracion.MORADO_OSCURO));
        btnGrabar.setMaxWidth(Double.MAX_VALUE);
        btnGrabar.setFont(Font.font("Times New Roman", TAMANIO_FUENTE));
        btnGrabar.setOnAction((e) -> guardarCliente());
        miGrilla.add(btnGrabar, 1, 8);
    }

    private Boolean formularioCompleto() {
        if (txtNombre.getText().isBlank()) {
            Mensaje.mostrar(Alert.AlertType.WARNING, this.getScene().getWindow(),
                    "Atención", "Por favor ingresa el nombre");
            txtNombre.requestFocus();
            return false;
        }
        if (txtApellido.getText().isBlank()) {
            Mensaje.mostrar(Alert.AlertType.WARNING, this.getScene().getWindow(),
                    "Atención", "Por favor ingresa el apellido");
            txtApellido.requestFocus();
            return false;
        }
        if (txtDocumento.getText().isBlank()) {
            Mensaje.mostrar(Alert.AlertType.WARNING, this.getScene().getWindow(),
                    "Atención", "Por favor ingresa el documento");
            txtDocumento.requestFocus();
            return false;
        }
        if (txtTelefono.getText().isBlank()) {
            Mensaje.mostrar(Alert.AlertType.WARNING, this.getScene().getWindow(),
                    "Atención", "Por favor ingresa el teléfono");
            txtTelefono.requestFocus();
            return false;
        }
        if (txtEmail.getText().isBlank()) {
            Mensaje.mostrar(Alert.AlertType.WARNING, this.getScene().getWindow(),
                    "Atención", "Por favor ingresa el email");
            txtEmail.requestFocus();
            return false;
        }
        return true;
    }

    private void guardarCliente() {
        if (formularioCompleto()) {
            ClienteDto dto = new ClienteDto();
            dto.setNombreCliente(txtNombre.getText());
            dto.setApellidoCliente(txtApellido.getText());
            dto.setDocumentoCliente(txtDocumento.getText());
            dto.setTelefonoCliente(txtTelefono.getText());
            dto.setEmailCliente(txtEmail.getText());
            dto.setCantidadBoletasCliente((short) 0);

            if (ClienteControladorGrabar.crearCliente(dto)) {
                Mensaje.mostrar(Alert.AlertType.INFORMATION, null,
                        "Éxito", "Cliente guardado correctamente");
                limpiarFormulario();
            } else {
                Mensaje.mostrar(Alert.AlertType.ERROR, null,
                        "Error", "No se pudo guardar el cliente");
            }
        }
    }

    private void limpiarFormulario() {
        txtNombre.setText("");
        txtApellido.setText("");
        txtDocumento.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        txtNombre.requestFocus();
    }

    private void colocarFrmElegante() {
        Runnable calcular = () -> {
            double alturaMarco = miMarco.getHeight();
            if (alturaMarco > 0) {
                double desplazamiento = alturaMarco * AJUSTE_TITULO;
                miGrilla.setTranslateY(alturaMarco / 8 + desplazamiento);
            }
        };

        calcular.run();
        miMarco.heightProperty().addListener((obs, antes, despues) -> {
            calcular.run();
        });
    }
}