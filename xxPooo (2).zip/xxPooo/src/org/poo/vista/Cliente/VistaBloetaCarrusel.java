/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.poo.vista.Cliente;


import java.util.List;
import javafx.animation.FadeTransition;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.poo.controlador.boleta.BoletaControladorListar;
import org.poo.dto.BoletaDto;
import org.poo.recurso.constante.Configuracion;
import org.poo.recurso.utilidad.Icono;
import org.poo.recurso.utilidad.Marco;

public class VistaBloetaCarrusel extends BorderPane {
    private final Stage miEscenario;
    private final VBox panelCentral;
    private int indiceActual = 0;
    private List<BoletaDto> boletas;

    public VistaBloetaCarrusel(Stage ventanaPadre, double ancho, double alto) {
        miEscenario = ventanaPadre;
        boletas = BoletaControladorListar.obtenerBoletas();
        panelCentral = new VBox(20);

        if (boletas.isEmpty()) {
            Text sinDatos = new Text("No hay boletas disponibles");
            sinDatos.setFont(Font.font("Rockwell", FontWeight.BOLD, 24));
            panelCentral.getChildren().add(sinDatos);
            setCenter(panelCentral);
            return;
        }

        construirPanelIzquierdo();
        construirPanelDerecho();
        construirPanelCentro();
    }

    private void construirPanelIzquierdo() {
        Button btnAnterior = new Button();
        btnAnterior.setGraphic(Icono.obtenerIcono("iconoEditar.png", 80));
        btnAnterior.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        btnAnterior.setCursor(Cursor.HAND);
        btnAnterior.setOnAction(e -> {
            indiceActual = (indiceActual - 1 + boletas.size()) % boletas.size();
            actualizarCarrusel();
        });

        StackPane panelIzquierdo = new StackPane();
        panelIzquierdo.prefWidthProperty().bind(miEscenario.widthProperty().multiply(0.14));
        panelIzquierdo.getChildren().add(btnAnterior);
        setLeft(panelIzquierdo);
    }

    private void construirPanelDerecho() {
        Button btnSiguiente = new Button();
        btnSiguiente.setGraphic(Icono.obtenerIcono("iconoEditar.png", 80));
        btnSiguiente.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        btnSiguiente.setCursor(Cursor.HAND);
        btnSiguiente.setOnAction(e -> {
            indiceActual = (indiceActual + 1) % boletas.size();
            actualizarCarrusel();
        });

        StackPane panelDerecho = new StackPane();
        panelDerecho.prefWidthProperty().bind(miEscenario.widthProperty().multiply(0.14));
        panelDerecho.getChildren().add(btnSiguiente);
        setRight(panelDerecho);
    }

    private void construirPanelCentro() {
        StackPane centerPane = new StackPane();
        Rectangle miMarco = Marco.crear(miEscenario, 0.70, 0.75,
                Configuracion.DEGRADE_ARREGLO_PELICULA, Configuracion.DEGRADE_BORDE);
        centerPane.getChildren().add(miMarco);

        panelCentral.setAlignment(Pos.TOP_CENTER);
        panelCentral.prefWidthProperty().bind(miEscenario.widthProperty());
        panelCentral.prefHeightProperty().bind(miEscenario.heightProperty());

        // Título con número
        Region espacioTitulo = new Region();
        espacioTitulo.prefHeightProperty().bind(miEscenario.heightProperty().multiply(0.1));
        panelCentral.getChildren().add(espacioTitulo);

        Text titulo = new Text("Detalle de Boleta");
        titulo.setFont(Font.font("Rockwell", FontWeight.BOLD, 28));
        titulo.setFill(Color.web(Configuracion.MORADO_OSCURO));
        panelCentral.getChildren().add(titulo);

        // Información de la boleta
        Label lblInfo = new Label();
        lblInfo.setFont(Font.font("Verdana", 18));
        lblInfo.setWrapText(true);
        panelCentral.getChildren().add(lblInfo);

        // Mostrar índice actual
        Text contador = new Text();
        contador.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
        contador.setFill(Color.web(Configuracion.MORADO_CLARO));
        panelCentral.getChildren().add(contador);

        centerPane.getChildren().add(panelCentral);
        setCenter(centerPane);

        // Inicializar con primer dato
        actualizarCarrusel();
    }

    private void actualizarCarrusel() {
        if (boletas.isEmpty()) return;

        BoletaDto boleta = boletas.get(indiceActual);
        
        // Efecto de desvanecimiento
        FadeTransition fadeOut = new FadeTransition(Duration.millis(300), panelCentral);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.3);
        fadeOut.setOnFinished(e -> {
            actualizarContenido(boleta);
            FadeTransition fadeIn = new FadeTransition(Duration.millis(300), panelCentral);
            fadeIn.setFromValue(0.3);
            fadeIn.setToValue(1.0);
            fadeIn.play();
        });
        fadeOut.play();
    }

    private void actualizarContenido(BoletaDto boleta) {
        VBox infoBox = new VBox(10);
        infoBox.setAlignment(Pos.TOP_LEFT);

        Label lblAsiento = new Label("Asiento: " + boleta.getNumeroAsientoBoleta());
        lblAsiento.setFont(Font.font("Verdana", 16));
        lblAsiento.setTextFill(Color.web(Configuracion.MORADO_OSCURO));

        Label lblFecha = new Label("Fecha de Compra: " + boleta.getFechaCompraBoleta());
        lblFecha.setFont(Font.font("Verdana", 16));
        lblFecha.setTextFill(Color.web(Configuracion.MORADO_OSCURO));

        Label lblEstado = new Label("Estado: " + (boleta.getEstadoBoleta() ? "Activa" : "Inactiva"));
        lblEstado.setFont(Font.font("Verdana", 16));
        Color colorEstado = boleta.getEstadoBoleta() ? Color.GREEN : Color.RED;
        lblEstado.setTextFill(colorEstado);

        infoBox.getChildren().addAll(lblAsiento, lblFecha, lblEstado);

        HBox contenedor = new HBox(infoBox);
        contenedor.setPadding(new javafx.geometry.Insets(20));

        Text contador = new Text((indiceActual + 1) + " / " + boletas.size());
        contador.setFont(Font.font("Verdana", FontWeight.BOLD, 14));
        
        panelCentral.getChildren().clear();
        panelCentral.getChildren().addAll(
            new Region() {{ setVgrow(this, Priority.ALWAYS); }},
            contenedor,
            contador
        );
    }
}
